### Name: Kill xConnect Processing service
### Description: This script kills xConnect Processing service service on target

param(
	[string]$Prefix
)

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-ProcessingEngineService"}).processID
taskkill /f /pid $ServicePID
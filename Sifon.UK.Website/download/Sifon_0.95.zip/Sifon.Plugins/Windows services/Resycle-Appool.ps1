### Name: Recycle AppPool
### Description: Recycle AppPool

param(
	[string]$Prefix
)

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-MarketingAutomationService"}).processID
taskkill /f /pid $ServicePID

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-ProcessingEngineService"}).processID
taskkill /f /pid $ServicePID

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-IndexWorker"}).processID
taskkill /f /pid $ServicePID
### Name: Kill all Sitecore windows services
### Description: This script kills: Markerting Automation, xConnect Processing and xConnect Search services on target

param(
	[string]$Prefix
)

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-MarketingAutomationService"}).processID
taskkill /f /pid $ServicePID

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-ProcessingEngineService"}).processID
taskkill /f /pid $ServicePID

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-IndexWorker"}).processID
taskkill /f /pid $ServicePID
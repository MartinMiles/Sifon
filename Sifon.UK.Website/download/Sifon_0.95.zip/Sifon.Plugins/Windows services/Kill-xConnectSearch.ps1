### Name: Kill xConnect Search service
### Description: This script kills xConnect Search service service on target

param(
	[string]$Prefix
)

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-IndexWorker"}).processID
taskkill /f /pid $ServicePID
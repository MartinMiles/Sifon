### Name: Show PC name
### Description: This script simply gets a computer name from OS environmentm. Helpful for testing remoting with Sifon

$pcName = $env:computername | Select-Object
Write-Output "Computer name: $pcName"
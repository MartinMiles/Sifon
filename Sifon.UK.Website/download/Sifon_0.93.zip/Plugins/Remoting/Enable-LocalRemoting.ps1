Get-NetConnectionProfile | Set-NetConnectionProfile -NetworkCategory Private
Enable-PSRemoting �force
Set-Item -Path WSMan:\localhost\Client\TrustedHosts -Value "*" -Force
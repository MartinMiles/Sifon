echo 'Hello from echo'

Write-Host "It is not recommended to use Write-Host method"
Write-Output "This is a better way of writing console output - use Write-Output method"

start-sleep -milli 500
Write-Information "Information"


#start-sleep -milli 500
#Write-Error "This was an error"


start-sleep -milli 500
Write-Warning "This was a warning"

start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 1" -PercentComplete 1
Write-Output "Progress 1%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 2" -PercentComplete 2
Write-Output "Progress 2%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 3" -PercentComplete 3
Write-Output "Progress 3%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 4" -PercentComplete 4
Write-Output "Progress 4%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 5" -PercentComplete 5
Write-Output "Progress 5%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 6" -PercentComplete 6
Write-Output "Progress 6%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 7" -PercentComplete 7
Write-Output "Progress 7%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 8" -PercentComplete 8
Write-Output "Progress 8%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 9" -PercentComplete 9
Write-Output "Progress 9%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 10" -PercentComplete 10
Write-Output "Progress 10%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 11" -PercentComplete 11
Write-Output "Progress 11%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 12" -PercentComplete 12
Write-Output "Progress 12%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 13" -PercentComplete 13
Write-Output "Progress 13%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 14" -PercentComplete 14
Write-Output "Progress 14%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 15" -PercentComplete 15
Write-Output "Progress 15%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 16" -PercentComplete 16
Write-Output "Progress 16%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 17" -PercentComplete 17
Write-Output "Progress 17%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 18" -PercentComplete 18
Write-Output "Progress 18%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 19" -PercentComplete 19
Write-Output "Progress 19%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 20" -PercentComplete 20
Write-Output "Progress 20%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 21" -PercentComplete 21
Write-Output "Progress 21%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 22" -PercentComplete 22
Write-Output "Progress 22%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 23" -PercentComplete 23
Write-Output "Progress 23%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 24" -PercentComplete 24
Write-Output "Progress 24%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 25" -PercentComplete 25
Write-Output "Progress 25%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 26" -PercentComplete 26
Write-Output "Progress 26%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 27" -PercentComplete 27
Write-Output "Progress 27%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 28" -PercentComplete 28
Write-Output "Progress 28%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 29" -PercentComplete 29
Write-Output "Progress 29%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 30" -PercentComplete 30
Write-Output "Progress 30%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 31" -PercentComplete 31
Write-Output "Progress 31%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 32" -PercentComplete 32
Write-Output "Progress 32%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 33" -PercentComplete 33
Write-Output "Progress 33%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 34" -PercentComplete 34
Write-Output "Progress 34%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 35" -PercentComplete 35
Write-Output "Progress 35%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 36" -PercentComplete 36
Write-Output "Progress 36%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 37" -PercentComplete 37
Write-Output "Progress 37%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 38" -PercentComplete 38
Write-Output "Progress 38%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 39" -PercentComplete 39
Write-Output "Progress 39%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 40" -PercentComplete 40
Write-Output "Progress 40%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 41" -PercentComplete 41
Write-Output "Progress 41%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 42" -PercentComplete 42
Write-Output "Progress 42%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 43" -PercentComplete 43
Write-Output "Progress 43%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 44" -PercentComplete 44
Write-Output "Progress 44%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 45" -PercentComplete 45
Write-Output "Progress 45%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 46" -PercentComplete 46
Write-Output "Progress 46%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 47" -PercentComplete 47
Write-Output "Progress 47%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 48" -PercentComplete 48
Write-Output "Progress 48%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 49" -PercentComplete 49
Write-Output "Progress 49%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 50" -PercentComplete 50
Write-Output "Progress 50%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 51" -PercentComplete 51
Write-Output "Progress 51%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 52" -PercentComplete 52
Write-Output "Progress 52%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 53" -PercentComplete 53
Write-Output "Progress 53%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 54" -PercentComplete 54
Write-Output "Progress 54%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 55" -PercentComplete 55
Write-Output "Progress 55%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 56" -PercentComplete 56
Write-Output "Progress 56%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 57" -PercentComplete 57
Write-Output "Progress 57%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 58" -PercentComplete 58
Write-Output "Progress 58%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 59" -PercentComplete 59
Write-Output "Progress 59%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 60" -PercentComplete 60
Write-Output "Progress 60%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 61" -PercentComplete 61
Write-Output "Progress 61%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 62" -PercentComplete 62
Write-Output "Progress 62%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 63" -PercentComplete 63
Write-Output "Progress 63%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 64" -PercentComplete 64
Write-Output "Progress 64%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 65" -PercentComplete 65
Write-Output "Progress 65%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 66" -PercentComplete 66
Write-Output "Progress 66%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 67" -PercentComplete 67
Write-Output "Progress 67%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 68" -PercentComplete 68
Write-Output "Progress 68%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 69" -PercentComplete 69
Write-Output "Progress 69%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 70" -PercentComplete 70
Write-Output "Progress 70%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 71" -PercentComplete 71
Write-Output "Progress 71%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 72" -PercentComplete 72
Write-Output "Progress 72%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 73" -PercentComplete 73
Write-Output "Progress 73%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 74" -PercentComplete 74
Write-Output "Progress 74%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 75" -PercentComplete 75
Write-Output "Progress 75%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 76" -PercentComplete 76
Write-Output "Progress 76%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 77" -PercentComplete 77
Write-Output "Progress 77%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 78" -PercentComplete 78
Write-Output "Progress 78%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 79" -PercentComplete 79
Write-Output "Progress 79%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 80" -PercentComplete 80
Write-Output "Progress 80%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 81" -PercentComplete 81
Write-Output "Progress 81%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 82" -PercentComplete 82
Write-Output "Progress 82%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 83" -PercentComplete 83
Write-Output "Progress 83%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 84" -PercentComplete 84
Write-Output "Progress 84%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 85" -PercentComplete 85
Write-Output "Progress 85%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 86" -PercentComplete 86
Write-Output "Progress 86%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 87" -PercentComplete 87
Write-Output "Progress 87%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 88" -PercentComplete 88
Write-Output "Progress 88%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 89" -PercentComplete 89
Write-Output "Progress 89%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 90" -PercentComplete 90
Write-Output "Progress 90%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 91" -PercentComplete 91
Write-Output "Progress 91%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 92" -PercentComplete 92
Write-Output "Progress 92%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 93" -PercentComplete 93
Write-Output "Progress 93%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 94" -PercentComplete 94
Write-Output "Progress 94%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 95" -PercentComplete 95
Write-Output "Progress 95%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 96" -PercentComplete 96
Write-Output "Progress 96%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 97" -PercentComplete 97
Write-Output "Progress 97%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 98" -PercentComplete 98
Write-Output "Progress 98%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 99" -PercentComplete 99
Write-Output "Progress 99%" 
 
start-sleep -milli 100
Write-Progress -Activity "This is the name of current operation" -CurrentOperation "Step 100" -PercentComplete 100
Write-Output "Progress 100%" 
 
 

### Name: Kill Markerting Automation service
### Description: This script kills Markerting Automation service on target

param(
	[string]$Prefix
)

$ServicePID = (get-wmiobject win32_service | where { $_.name -eq "$Prefix.xconnect-MarketingAutomationService"}).processID
taskkill /f /pid $ServicePID
param(
    [string]$Directory
)
Test-Path $Directory
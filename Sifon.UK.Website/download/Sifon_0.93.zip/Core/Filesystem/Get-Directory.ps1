param(
    [string]$Directory
)
Get-Item $Directory
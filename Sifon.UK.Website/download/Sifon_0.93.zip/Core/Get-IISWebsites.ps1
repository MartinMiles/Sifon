param
(
	[string]$Name = ''
)

if($Name)
{
	Get-IISSite $Name | Select-Object -Property Name
}
else{
	Get-IISSite | Select-Object -Property Name
}
